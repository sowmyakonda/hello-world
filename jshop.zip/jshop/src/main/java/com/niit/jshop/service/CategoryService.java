package com.niit.jshop.service;

import java.util.List;


import com.niit.jshop.model.CategoryModel;

public interface CategoryService {
	public void addCategory(CategoryModel ndm);
	public String deleteCategory(String cid);
	public int updateCategory(CategoryModel ndm);
	List<CategoryModel> getCategoryList();
	
}
