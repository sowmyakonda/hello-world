package com.niit.jshop.controller;

import java.util.ArrayList;




import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.jshop.dao.UserDAO;
import com.niit.jshop.dao.UserDAOImpl;

import com.niit.jshop.model.ProductModel;
import com.niit.jshop.model.UserDetails;
import com.niit.jshop.service.ProductService;



@Controller
public class HomeController {
@Autowired
	private ProductService devserv;
@Autowired
private SessionFactory sessionFactory; 
	String setName = "";
	
	@RequestMapping("/")
	public ModelAndView getFirstPage(){	
		System.out.println("\n/request maped with welcome jsp");
		ModelAndView mv = new ModelAndView("home");
		return mv;
	}	
	@RequestMapping("/aboutus")
	public ModelAndView getaboutus(){	
		System.out.println("\n/request maped with welcome jsp");
		ModelAndView mv = new ModelAndView("about");
		return mv;
	}	
	@RequestMapping("/products")
	public ModelAndView getguestpage(){	
		System.out.println("\n/request maped with welcome jsp");
		ModelAndView mv = new ModelAndView("guestpage");
		return mv;
	}	

	@RequestMapping("/page0")
	public ModelAndView getPage1(){	
		System.out.println("\n/request maped with page0 jsp");
		ModelAndView mv = new ModelAndView("page0");
		return mv;
	}
	@RequestMapping("/device")
	public ModelAndView AllProductCode(
			@RequestParam(value = "name", required = false, defaultValue = "DEVICE") String name) {
		System.out.println("\n/request maped with page1 jsp(alias device)");
		ModelAndView allprod = new ModelAndView("page1");
		setName = name;
		System.out.println("\n/device - " + setName);
		return allprod;
	}
	@RequestMapping("loginSuccessAdmin")
	public ModelAndView adminpage(){	
		System.out.println("\n/request maped with welcome jsp");
		ModelAndView mv = new ModelAndView("loginSuccessAdmin");
		return mv;
	}
	@RequestMapping("loginSuccessUser")
	public ModelAndView userpage(){	
		System.out.println("\n/request maped with welcome jsp");
		ModelAndView mv = new ModelAndView("loginSuccessUser");
		return mv;
	}	
	@RequestMapping("/GsonCon")
	public @ResponseBody String getValues() {
			
		//ndd = new ProductDAOImpl();
		String devs="";
		
		if("alldev".equals(setName)){
			
			System.out.println("gson all devices...");
			List <ProductModel> listdev = devserv.getAllDevices();
			Gson gson = new Gson();
			devs=gson.toJson(listdev);
			System.out.println("at the end of all devices");
		}
		else{		
			System.out.println("gson one device...");
			ProductModel nd = ProductModel.getProduct(setName);
			List <ProductModel> ld = new ArrayList<ProductModel>();
			ld.add(nd);
			Gson gson=new Gson();
			devs=gson.toJson(ld);
			System.out.println("at the end of one device");
		}
		return devs;
	}
	@RequestMapping("/GsonConAdmin")
	public @ResponseBody String getDataforAdmin() {
			
		//ndd = new NetworkDevDAOImpl();
		String devs="";	
	
			System.out.println("gson all devices...Admin");
			List <ProductModel> listdev = devserv.getAllDevices();
			Gson gson = new Gson();
			devs=gson.toJson(listdev);
		
		return devs;
	}
	@RequestMapping("/addDev") // from welcome.jsp
	public ModelAndView addDevice() {
		System.out.println("in add dev controller");
		System.out.println("\nMyContoller - addDev");
		ModelAndView mv = new ModelAndView("addDevice");
		return mv;
		//return null;
	}
	
	@RequestMapping("/addDevice") // from addDevice.jsp
    public ModelAndView storeProduct(@RequestParam(value="ProductId")String did,@RequestParam(value="ProductName")String dn,
    		@RequestParam(value="ProductCategory")String dcat,@RequestParam(value="ProductDetails")String ddet,
    		@RequestParam(value="ProductPrice")String dprice,
    		@RequestParam(value="ProductPhotoURL")String durl)
    {
    	System.out.println("In Add device method : " + dn );
    	ProductModel p = new ProductModel();
    	p.setProductID(Integer.parseInt(did));
    	p.setProductName(dn);
    	p.setProductCategory(dcat);
    	p.setProductDetails(ddet);
    	p.setProductPrice(Integer.parseInt(dprice));
    	p.setProductPhotoURL(durl);    	
    	//System.out.println("test:"+p.getDeviceName());
    	
    	devserv.addDevice(p);
    	//return new ModelAndView("ProductsAdded", "message", "");
    	return null;
    }

	@RequestMapping("/login") // from welcome.jsp
	public ModelAndView loginpage() {
		System.out.println("\nMyContoller - loginpage");
		ModelAndView mv = new ModelAndView("login");
		return mv;
		//return null;
	}
	
	@RequestMapping("/logincheck") // from login.jsp
	public ModelAndView logincheck(@RequestParam(value="userid")String userid,@RequestParam(value="pwd")String passwd) {
		System.out.println("\nMyContoller - logincheck");
		ModelAndView mv;
		System.out.println("\nMyContoller - /loginCheck - before session factory");
		UserDAO ud = new UserDAOImpl(sessionFactory);
		System.out.println("\nMyContoller - /loginCheck - after session factory");
		
		if(ud.isValidUser(userid,passwd)==true  && ud.isAdminUser(userid, passwd)==true) {
			System.out.println("login ok - admin");
			mv=new ModelAndView("admin");
			mv.addObject("username",userid);
		}
		else if(ud.isValidUser(userid,passwd)==true){
			System.out.println("login ok - user");
			mv=new ModelAndView("user");
		}
		else {
		System.out.println("login not ok");			
		mv=new ModelAndView("loginerror");
		}
		return mv;	
	}
	@RequestMapping("/homeFromLogin")
	public ModelAndView getHomePage(){	
		System.out.println("\n/ request maped back to welcome from login success");
		ModelAndView mv = new ModelAndView("welcome");
		return mv;
}
	
	@RequestMapping("/deleteDevice") // from page1.jsp
	public ModelAndView deleteDevice(@RequestParam(value="id")String did) {
	//	System.out.println("id:"+req.getParameter("DeviceId"));
		System.out.println(did);
		
		System.out.println("\nHomeController - deleteDevice - " + did);
		int id = Integer.parseInt(did);
		devserv.deleteDevice(id);
		System.out.println("\nHomeContoller - deleteDevice - " + id + " - completed");
		ModelAndView mv = new ModelAndView("page1");		
		return mv;		
	}

	@RequestMapping("/editDevice") // from page1.jsp
	public ModelAndView editDevice(@RequestParam(value="id")String did, HttpServletRequest request) {
	//	System.out.println("id:"+req.getParameter("DeviceId"));
		System.out.println(did);
		System.out.println("\nMyContoller - editDevicePage - " + did);
		int id = Integer.parseInt(did);
		//devserv.deleteDevice(id);
		ProductModel nd = new ProductModel();
		Session s = sessionFactory.openSession();
		ModelAndView mv = new ModelAndView("editDevicePage");
		
		ProductModel nd1 = (ProductModel)s.get(ProductModel.class,id);
		HttpSession session = request.getSession();
		session.setAttribute("data", nd1);				
		session.setAttribute("devid",did);
		mv.addObject("devid",did);
		mv.addObject("command",nd1);
		//String str=(String)session.getAtt
		System.out.println("\nMyContoller - editDevicePage - " + id + " - completed");
		return mv;		
	}
	
	@RequestMapping("editDeviceData")
	public ModelAndView update(@ModelAttribute("abcd")ProductModel p) 
	 {
		devserv.updateDevice(p);
		return new ModelAndView("loginSuccessAdmin");  
	 }
	
	@RequestMapping("register")
	public ModelAndView registerUser(){
		ModelAndView mv = new ModelAndView("userRegistration1");
		
		return mv;
	}

	//registerUser
	@RequestMapping("registerUser")
	public ModelAndView regUser(@RequestParam(value="userid")String uid,@RequestParam(value="password")String pwd,
    		@RequestParam(value="emailid")String email,@RequestParam(value="mobilenumber")String mobile,
    		@RequestParam(value="address")String addr,@RequestParam(value="city")String cit,
    		@RequestParam(value="state")String st,@RequestParam(value="country")String cnt )
	{
		System.out.println("regusteruser");
		UserDetails ud = new UserDetails();
		
		ud.setUID(uid);
		ud.setPassword(pwd);
		ud.setAdmin(false);
		ud.setStatus("valid");
		ud.setEmailId(email);
		ud.setMobileNo(mobile);
		ud.setAddress(addr);
		ud.setCity(cit);
		ud.setState(st);
		ud.setCountry(cnt);		
		
		UserDAO udao = new UserDAOImpl(sessionFactory);
		udao.addUser(ud);
		
		
		
		return null;
	}

	

	
}
