package com.niit.jshop.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name="CategoryModelll")
	public class CategoryModel {
		@Id 
		private int CategoryId;
		private String CategoryName;
		private String CategoryDescription;
		public int getCategoryId() {
			return CategoryId;
		}
		public String getCategoryName() {
			return CategoryName;
		}
		public void setCategoryName(String categoryName) {
			CategoryName = categoryName;
		}
		public String getCategoryDescription() {
			return CategoryDescription;
		}
		public void setCategoryDescription(String categoryDescription) {
			CategoryDescription = categoryDescription;
		}
		public void setCategoryId(int categoryId) {
			CategoryId = categoryId;
		}
			
		
	}

	
	

