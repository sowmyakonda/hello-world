package com.niit.jshop.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.jshop.dao.ProductDAO;
import com.niit.jshop.model.ProductModel;
@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductDAO deviceData;
	
	public List<ProductModel> getAllDevices() {
		// TODO Auto-generated method stub
		System.out.println("\nNetworkDevServ-getAllDev()");
		return deviceData.getAllDevices();
	}

	public void addDevice(ProductModel ndm) {
		
		// TODO Auto-generated method stub
				System.out.println("\nProductService-addDevice()");
				deviceData.addDevice(ndm); 
	}


	public ProductModel getDevice(String did) {
		// TODO Auto-generated method stub
		return null;
	}

	public String updateDevice(ProductModel ndm) {
		// TODO Auto-generated method stub
		deviceData.editDevice(ndm);
		return null;
	}


	
	
	public void addProduct(ProductModel p) {
		// TODO Auto-generated method stub
		
	}

	
	public int deleteDevice(int did) {
		// TODO Auto-generated method stub
		return deviceData.delDevice(did);
	
	}


}


