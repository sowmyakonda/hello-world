package com.niit.jshop.dao;

import java.util.List;


import com.niit.jshop.model.ProductModel;

public interface ProductDAO {
		public List<ProductModel> getAllDevices();

		public void addDevice(ProductModel ndm); 
		public ProductModel getDevice(int did);

		public String editDevice(ProductModel ndm);
		public int delDevice(int did);

		


}
