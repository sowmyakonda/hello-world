package com.niit.jshop.service;

import com.niit.jshop.model.UserDetails;

public interface UserService {
	public boolean isValidUser(String un, String pd);
	public void addUser(UserDetails ud);
}
