package com.niit.jshop.service;

import java.util.List;

import com.niit.jshop.model.ProductModel;

public interface ProductService {

	List<ProductModel> getAllDevices();

	
	public ProductModel getDevice(String did);
	public String updateDevice(ProductModel ndm);
	public int deleteDevice(int did);

	void addProduct(ProductModel p);


	public void addDevice(ProductModel ndm);


	



}
