package com.niit.jshop.service;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.jshop.dao.UserDAO;
import com.niit.jshop.model.UserDetails;

public class UserServiceImpl implements UserService {

	//@Autowired
	private UserDAO udao;
 	
	@Autowired
	private SessionFactory sessionFactory;   
	
	
	public UserServiceImpl(SessionFactory sf){
		this.sessionFactory =sf;
	}
	
	public boolean isValidUser(String un, String pd) {
		// TODO Auto-generated method stub
		System.out.println("UserServImpl - isValidUser() - started....");
		return udao.isValidUser(un, pd);			
	}
	
	public void addUser(UserDetails ud){
		System.out.println("\nUserServImpl - addUser()");
		udao.addUser(ud); 	
	}


}
