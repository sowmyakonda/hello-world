package com.niit.jshop.dao;

import java.util.List;


import com.niit.jshop.model.CategoryModel;


public interface CategoryDAO {
	public void addCategory(CategoryModel ndm); 
	public String deleteCategory(String cid);
	public List<CategoryModel> getCategoryList();
	public String editCategory(CategoryModel ndm);
}
