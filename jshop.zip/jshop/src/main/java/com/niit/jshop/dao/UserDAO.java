package com.niit.jshop.dao;

import com.niit.jshop.model.UserDetails;

public interface UserDAO {

	 boolean isValidUser(String un, String pd);

	public void addUser(UserDetails ud);

	 public boolean isAdminUser(String uid, String pd);
}
